package lab5;

import lejos.hardware.Sound;
import lejos.hardware.lcd.TextLCD;
import lejos.hardware.motor.EV3LargeRegulatedMotor;
import lejos.hardware.sensor.EV3ColorSensor;

public class ObjectDetection extends Thread{
	
	
	private final double COLOR_SENSOR_RANGE =3.5;  //CM
	private final double DISTANCE_THRESHOLD = 100.0;    //cm
	private TextLCD t;
	private USPoller usPoller;
	private LightSensorPoller lightSensorPoller;
	
	//constructor
	public ObjectDetection(USPoller usPoller, LightSensorPoller lightSensorPoller, TextLCD t){
		this.usPoller = usPoller;
		this.lightSensorPoller = lightSensorPoller;
		this.t = t;
	}
		
	//
	public void run(){		
		while(true){
			
			t.clear();	
						
			while(usPoller.getDistance() < DISTANCE_THRESHOLD)
			{
				t.drawString("Object Detected", 0, 0);
				//Sound.beep();
				//System.out.println(trueColor());
							
				if(usPoller.getDistance() <= COLOR_SENSOR_RANGE && lightSensorPoller.checkBlue() == true)
				{
					//clear y = 1
					t.clear(1);
					//draw at y = 1s
					t.drawString("Block", 0, 1);
				}
				else 
				{
					//colorID is not equal to 2
					//check if distance is within color sensor working range
					if(usPoller.getDistance() <= COLOR_SENSOR_RANGE){
						t.clear(1);
						t.drawString("Not block", 0, 1);
					}
					else{
						t.clear(1);
					}
				}
			}			
			t.drawString("No Object", 0, 0);
		}
	}
}

