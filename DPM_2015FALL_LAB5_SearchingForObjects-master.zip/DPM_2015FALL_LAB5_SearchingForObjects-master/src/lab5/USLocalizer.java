package lab5;

import lejos.hardware.Sound;
import lejos.hardware.motor.EV3LargeRegulatedMotor;
import lejos.robotics.SampleProvider;

public class USLocalizer {
	public enum LocalizationType { FALLING_EDGE, RISING_EDGE };
	public static double ROTATION_SPEED = 30;

	private Odometer odo;
	private SampleProvider usSensor;
	private float[] usData;
	private LocalizationType locType;
	private int d = 26;
	private Navigation navigation;
	private EV3LargeRegulatedMotor leftMotor;
	private EV3LargeRegulatedMotor rightMotor;	
	
	public USLocalizer(Odometer odo,  SampleProvider usSensor, float[] usData, Navigation navigation, LocalizationType locType ,  EV3LargeRegulatedMotor leftMotor,  EV3LargeRegulatedMotor rightMotor) {
		this.odo = odo;
		this.usSensor = usSensor;
		this.usData = usData;
		this.locType = locType;
		this.navigation = navigation;
		this.leftMotor = leftMotor;
		this.rightMotor = rightMotor;
		
	}

	
	public void doLocalization() {
		leftMotor.setSpeed(50);
		rightMotor.setSpeed(50);
		double angleA=0, angleB=0, dtheta=0;
		int i=0;
		
		if (locType == LocalizationType.FALLING_EDGE) {
			{
			// rotate the robot until it sees no wall
			while (getFilteredData()<50 || i < 10)
			{
				leftMotor.forward();
				rightMotor.backward();
				
				if (getFilteredData()==50)
				i++;
			}
	
			// keep rotating until the robot sees a wall, then latch the angle
			while (getFilteredData()> d)
			{
			leftMotor.forward();
			rightMotor.backward();
			}
			
			angleA = angleWrap(odo.getTheta());
			Sound.beep();
			
			// switch direction and wait until it sees no wall
			while (getFilteredData()<50)
			{
				leftMotor.backward();
				rightMotor.forward();
			}			
			try {Thread.sleep(2000); }catch (InterruptedException e){}			
			// keep rotating until the robot sees a wall, then latch the angle
				while (getFilteredData()> d)
				{
				leftMotor.backward();
				rightMotor.forward();
				}
				angleB = angleWrap(odo.getTheta());
				Sound.beep();				
				if (angleA > angleB)
				{
					dtheta = (Math.PI/4.0 - (angleA+angleB)/2);
				}
				else
				{
					dtheta = ((5.0/4.0)*Math.PI - (angleA+angleB)/2);
				}				
			// angleA is clockwise from angleB, so assume the average of the
			// angles to the right of angleB is 45 degrees past 'north'
			// update the odometer position (example to follow:)
			odo.setPosition(new double [] {0, 0, angleWrap((odo.getTheta()))+dtheta}, new boolean [] {true, true, true});
			navigation.setOrientationToYpositive();	
			}	
			}
		else
		{}
		}		
			
	private float getFilteredData() {
		usSensor.fetchSample(usData, 0);
		float distance = usData[0]*100;
		if (distance > 50)
		{
			distance = 50;
		}				
		return distance;
	}

	public static double angleWrap(double angle) {
		if (angle < 0.0)
			angle = (2*Math.PI) + (angle);

		return (angle);
	}	
} 