package lab5;

import lejos.robotics.SampleProvider;

public class LightSensorPoller extends Thread{
	//variables
	private boolean isBlue = false;
	private Object lock;
	private SampleProvider colorSensor;
	private float[] colorData;
	//constructor
	public LightSensorPoller(SampleProvider colorSensor, float[] colorData){
		this.colorSensor = colorSensor;
		this.colorData = colorData;
		this.lock = new Object();
	}
	//
	public void run(){		
		while(true){
			synchronized (lock) {
				
				colorSensor.fetchSample(colorData, 0);
				//colorData[0] stands for red, colorData[1] stands for green, colorData[2] is blue
				if ( colorData[0] < .05 && (colorData[1] + colorData[2]) >.03){
					isBlue = true;					
				}
				else{
					isBlue = false;
				}
				try { Thread.sleep(20); } catch(Exception e){}		//timed sampling rate
			}			
		}
	}
	//if ID = 2, blue is detected
		
	public boolean checkBlue(){
		synchronized (lock) {
			return this.isBlue;
		}		
	}
}
	
/*public int trueColor(){
		
		int bufferSize = 100;
		int maxCount = 1;
		int count = 1;
		int maxColorID=-5;
	
		int[] bufferArray = new int[bufferSize];
		for (int i=0; i<bufferSize; i++)
		{
		bufferArray[i]= colorID;
		System.out.println("GETTINGCOLORID");
		}
		java.util.Arrays.sort(bufferArray);
		
		System.out.println("SORTED");
		for (int i=0; i<bufferSize-1; i++)
		{
		if (bufferArray[i+1] == bufferArray[i]){
			count++;
			System.out.println("IF");
		}
		else if (count > maxCount){
			maxColorID = bufferArray[i];
			maxCount = count;
			count = 1;
			System.out.println("ELSE IF");
		}
		}
			
		return maxColorID;
	}
}
*/