package lab5;

import lejos.hardware.Button;
import lejos.hardware.Sound;
import lejos.hardware.motor.EV3LargeRegulatedMotor;

public class MoveForSearching extends Thread{
	//constants
	private final int DeltaIncrease = 15;
	private final int FORWARD_SPEED = 200;
	private final int SCANNING_SPEED = 30;
	
	private final double UpperCornerX = 65;
	private final double UpperCornerY = 65;
	private final double SCANNNING_RANGE = 60.0;
	private final double DISTANCE_THRESHOLD = 3.5;    //cm
	//variables
	private EV3LargeRegulatedMotor leftClaw, rightClaw;
	private USPoller usPoller;
	private LightSensorPoller lightSensorPoller;
	private volatile boolean usDetectingObstacles = false;
	private volatile boolean colorSensorDetectingBlueObstacle = false;
	private Navigation navigation;
	private Odometer odometer;
	//constructor
	public MoveForSearching(Navigation navigation, Odometer odometer, USPoller usPoller, LightSensorPoller lightSensorPoller,EV3LargeRegulatedMotor leftClaw, EV3LargeRegulatedMotor rightClaw){
		this.rightClaw = rightClaw;
		this.leftClaw =  leftClaw;
		this.navigation = navigation;
		this.odometer = odometer;
		this.usPoller = usPoller;
		this.lightSensorPoller = lightSensorPoller;
	}
	//setters 
	public void setUsDetectingObstacles(boolean usDetectingObstacles) {
		this.usDetectingObstacles = usDetectingObstacles;
	}
	
	public void setColorSensorDetectingBlueObstacle(boolean colorSensorDetectingBlueObstacle) {
		this.colorSensorDetectingBlueObstacle = colorSensorDetectingBlueObstacle;
	}
	//
	public void run(){
		
		odometer.setPosition (new double[] {0.0, 0.0, 0.0} , new boolean[] {true, true, true} );
		
		double obstaclesDirection;
		//while
		double x = 0.0;
		double y = 0.0;
		
		while(true){
			
			x = x + DeltaIncrease;
			y = y + DeltaIncrease;
			//this is the direction exits object
			obstaclesDirection = scan(x, y);
			
			if(usDetectingObstacles == true){
				//turn to the direction that exits obstacle
				navigation.turnToAngle(obstaclesDirection);
				//Button.waitForAnyPress();
				//get close to obstacle
				while(usPoller.getDistance() >= DISTANCE_THRESHOLD){
					navigation.setSpeeds(FORWARD_SPEED, FORWARD_SPEED);
				}
				//stop
				navigation.setSpeeds(0, 0);
				
				//stop for 0.5s for color sensor update data
				try {
					Thread.sleep(500);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				//use color sensor data to check if the obstacle is blue
				if(lightSensorPoller.checkBlue() == true){
					colorSensorDetectingBlueObstacle = true;
					Sound.twoBeeps();
					releaseClaws();
				}else{
					//object is not blue syrofoam
					colorSensorDetectingBlueObstacle = false;
					Sound.beep();
					//
					avoidObjects(x,y);
				}
				
				if(usDetectingObstacles==true && colorSensorDetectingBlueObstacle == true){
					break;
				}
				
			}
			else{
				navigation.travelTo(x, y);
			}
		}
		//while
		navigation.travelTo(UpperCornerX, UpperCornerY);		
	}
	public void avoidObjects(double x, double y){
		navigation.turnToPoint(x, y);
		if(usPoller.getDistance() >= 15.0){
			return;
		}else{
			navigation.travelStraight(10, 1);
			navigation.turnTo(-Math.PI/4.0, false);
			navigation.travelStraight(10, 0);
			avoidObjects(x,y);
		}
	}
	
	public void releaseClaws(){
		leftClaw.setSpeed(200);
		rightClaw.setSpeed(200);
		leftClaw.rotate(-200);
		rightClaw.rotate(-200);
	}
	
	public double scan(double x, double y){
		
		//
		double directionExitsObstacles = 0.0;
		double startAngle = odometer.getTheta();
		double distance;
		
		//start scanning, scanning range pi/2		
		while(Math.abs(odometer.getTheta() - startAngle) < Math.PI/2.0){
			//start rotating for scanning
			navigation.setSpeeds(SCANNING_SPEED, -SCANNING_SPEED);
			//require US data
			distance = usPoller.getDistance();
			
			//once we detect some object, record current theta, set robot towards y positive, and stop scanning
			if(distance < SCANNNING_RANGE){
				//if detect something, stop
				navigation.setSpeeds(0, 0);
				//
				usDetectingObstacles = true;
				directionExitsObstacles = odometer.getTheta();
				//
				navigation.setOrientationToYpositive();
				System.out.println(directionExitsObstacles);
				//Button.waitForAnyPress();
				break;
			}
		}
		
		if(usDetectingObstacles == true){
			//return recorded direction with angle correction
			return directionExitsObstacles + 2*Math.PI/360.0*5.0;
		}else{
			usDetectingObstacles = false;
			return 0.0;
		}		
	}
}
