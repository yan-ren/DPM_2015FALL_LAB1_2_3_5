/* 
 * OdometryCorrection.java
 */
package lab2;
import lejos.hardware.Sound;
import lejos.hardware.port.SensorPort;
import lejos.hardware.sensor.EV3ColorSensor;


public class OdometryCorrection extends Thread {
	private static final long CORRECTION_PERIOD = 10;
	private Odometer odometer;
	private double brightness;
	private double brightnessThreshold = 0.35;
	private boolean isBlackLine = false;
	private int i=0;
	private int j=0;
	private int k=0;
	private static final double del=4.8;//distance from the color sensor to the centre of robot.
	private float intensity[] = new float[3];
	private EV3ColorSensor colorSensor;

	// constructor
	public OdometryCorrection(Odometer odometer) {
		this.odometer = odometer;
		this.colorSensor = new EV3ColorSensor(SensorPort.S1);
		Sound.setVolume(100);
	}

	// run method (required for Thread)
	public void run() {
		long correctionStart, correctionEnd;

		while (true) {
			correctionStart = System.currentTimeMillis();
			// put your correction code here
			colorSensor.setFloodlight(lejos.robotics.Color.WHITE);
			colorSensor.getRGBMode().fetchSample(intensity, 0);
			//get three latest values from color sensor
			brightness = (intensity[0] + intensity[1] + intensity[2]);
			//filter the blurry black line
			if (brightness< brightnessThreshold)
			{
				isBlackLine = true;
			}
			else 
			{
				isBlackLine = false;
			}
			
			if (isBlackLine==true)
				correctOdometer();


			// this ensure the odometry correction occurs only once every period
			correctionEnd = System.currentTimeMillis();
			if (correctionEnd - correctionStart < CORRECTION_PERIOD) {
				try {
					Thread.sleep(CORRECTION_PERIOD
							- (correctionEnd - correctionStart));
				} catch (InterruptedException e) {
					// there is nothing to be done here because it is not
					// expected that the odometry correction will be
					// interrupted by another thread
				}
			}
		}
	}
	//k records the times when robot cross black
	//when k=1, k=2, k=5 or k=6 means robot is moving in y direction, else is in x direction 
	private boolean isYcrossing(double Ypos)
	{
		k++;
		if (k == 1 || k ==2 || k ==5 || k==6)
		return true;
		else
		return false;
	}
	
	private void correctOdometer(){
		
		double Ypos = odometer.getY();
		double Xpos = odometer.getX();
		boolean Ycrossing = isYcrossing(Ypos);
		//check robot is moving in which direction
		if (Ycrossing)
		{
			Ycrossing = false;
			Sound.beep();
			updateY(Ypos);			  
		}
		else
		{
			Sound.beep();
			updateX(Xpos);
		}
	}
	//when moving in y direction, update the y value
	public void updateY(double oldY){
		double correctY=0;
		i++;
		if (i==1)
			correctY = 15.24-del;
		else if (i==2)
			correctY = 45.67-del;
		else if (i==3)
			correctY = 45.67+del;
		else if (i==4)
			correctY = 15.24+del;
		
		odometer.setY(correctY);
	}
	// when moving in x direction, update the x value
	public void updateX(double oldX){
		double correctX;
		j++;
		if (j==1)
			correctX = 15.24-del;
		else if (j==2)
			correctX = 45.67-del;
		else if (j==3)
			correctX = 45.67+del;
		else
			correctX = 15.24+del;
		
		odometer.setX(correctX);
		}
	}
