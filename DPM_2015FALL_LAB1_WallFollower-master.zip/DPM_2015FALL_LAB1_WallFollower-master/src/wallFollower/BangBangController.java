package wallFollower;
import lejos.hardware.motor.*;

public class BangBangController implements UltrasonicController{
	private final int bandCenter, bandwidth;
	private final int motorLow, motorHigh;
	private int distance;
	private EV3LargeRegulatedMotor leftMotor, rightMotor;
	
	//parameters
	private final int deltaSpeed = 50;
	private final int countBound = 60; //for countTimesDistanceOutOfRange, 40 equals to 2s.
	private int error=0;	
	int count = 0;
	private boolean haveAConvexCorner = false;
	
//	private final int FILTER_OUT = 20;
//	private int filterControl;
	//
	
	public BangBangController(EV3LargeRegulatedMotor leftMotor, EV3LargeRegulatedMotor rightMotor,
							  int bandCenter, int bandwidth, int motorLow, int motorHigh) {
		//Default Constructor
		this.bandCenter = bandCenter;        /* private static final int bandCenter = 30;			// Offset from the wall (cm)
	                                            private static final int bandWidth = 2;				// Width of dead band (cm)
	                                            private static final int motorLow = 100;			// Speed of slower rotating wheel (deg/sec)
	                                            private static final int motorHigh = 200;			// Speed of the faster rotating wheel (deg/seec)
		                                     */
		this.bandwidth = bandwidth;
		this.motorLow = motorLow;
		this.motorHigh = motorHigh;
		this.leftMotor = leftMotor;
		this.rightMotor = rightMotor;
		leftMotor.setSpeed(motorHigh);				// Start robot moving forward
		rightMotor.setSpeed(motorHigh);
		leftMotor.forward();
		rightMotor.forward();
	}
	
	@Override
	public void processUSData(int distance) {
		this.distance = distance;
		
		
		error = (this.distance- bandCenter);
		
		if(Math.abs(error) <= bandwidth){
			leftMotor.setSpeed(motorHigh);
			rightMotor.setSpeed(motorHigh);
			leftMotor.forward();
			rightMotor.forward();
			return;
		}
		
		if (haveAConvexCorner==true){
			if (error > bandCenter){
				turnConvexCorner();
				return;
			}
			else{
				leftMotor.stop();
				rightMotor.stop();
				haveAConvexCorner=false;
				count=0;
			}
		}
				
		//too far from the wall
		if (error>0){
			//when 0 < error < bandCenter 
			if(error < bandCenter){				
				count =0;
				
				leftMotor.setSpeed(motorHigh-deltaSpeed);
				rightMotor.setSpeed(motorHigh);
				leftMotor.forward();
				rightMotor.forward();
			}
			
			//when error > bandCenter
			//robot is either too far from wall or maybe a gap.
			else{				
				if(count < countBound){
					count++;
					leftMotor.setSpeed(motorLow);
					rightMotor.setSpeed(motorLow);
					leftMotor.forward();
					rightMotor.forward();
					return;
				}
				else{
					haveAConvexCorner=true;
					return;
				}
			}
		}
		
		//too close to the wall
		else if (error < 0){
			count = 0;
			if (error< -15){
				rightMotor.stop();
				leftMotor.setSpeed(motorHigh);				
				leftMotor.forward();				
			}
			else{
				leftMotor.setSpeed(motorHigh);
				rightMotor.setSpeed(motorHigh-deltaSpeed);
				leftMotor.forward();
				rightMotor.forward();
			}
		}
	}

	@Override
	public int readUSDistance() {
		return this.distance;
	}
	
	public void turnConvexCorner(){
			leftMotor.setSpeed(80);
			rightMotor.setSpeed(motorHigh);				
			rightMotor.forward();
			leftMotor.forward();
	}
}
